<!DOCTYPE html>
<html>
<head>
	<title>Restaurante | ConfiguroWeb</title>
	<link rel="stylesheet" href="./style.css">


<h1 style="text-align:center;">Restaurante | ConfiguroWeb</h1>


	<a href="staff" >Empleado</a>
	<a href="admin">Administrador</a>






</head>
<body>
</div>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>


	
</body>
</html>